<?php
 $connect = mysqli_connect("localhost", "root", "", "logtest");
 session_start();
 if(isset($_SESSION["username"]))
 {
      header("location:entry.php");
 }
 if(isset($_POST["register"]))
 {
      if(empty($_POST["username"]) && empty($_POST["password"]))
      {
           echo '<script>alert("Both Fields are required")</script>';
      }
      else
      {
           $username = mysqli_real_escape_string($connect, $_POST["username"]);
           $password = mysqli_real_escape_string($connect, $_POST["password"]);
           $password = md5($password);
           $query = "INSERT INTO users (username, password) VALUES('$username', '$password')";
           if(mysqli_query($connect, $query))
           {
                echo '<script>alert("Registration Done")</script>';
           }
      }
 }
 if(isset($_POST["login"]))
 {
      if(empty($_POST["username"]) && empty($_POST["password"]))
      {
           echo '<script>alert("Both Fields are required")</script>';
      }
      else
      {
           $username = mysqli_real_escape_string($connect, $_POST["username"]);
           $password = mysqli_real_escape_string($connect, $_POST["password"]);
           $password = md5($password);
           $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
           $result = mysqli_query($connect, $query);
           if(mysqli_num_rows($result) > 0)
           {
                $_SESSION['username'] = $username;
                header("location:entry.php");
           }
           else
           {
                echo '<script>alert("Wrong User Details")</script>';
           }
      }
 }
 ?>
 <!DOCTYPE html>
 <html>
      <head>

           <title>SEC CODING-CH #2 : SECURE LOGIN</title>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
      </head>
      <body style="background-color:PowderBlue;">
           <br /><br />
           <div class="container" style="width:500px;">
                <h3 style="color:Tomato;" align="center"><b><u>WEB APPLICATION WITH ENCRYPTED CREDENTIALS</u></b></h3>
                <br />
                <?php
                if(isset($_GET["action"]) == "login")
                {
                ?>
                <h3 align="center">Login</h3>
                <br />
                <form style="background-color:Khaki;" method="post">
                     <label style="color:Blue;"><b><u>Enter Username</u></b></label>
                     <input type="text" name="username" class="form-control" />
                     <br />
                     <label style="color:Blue;"><b><u>Enter Password</b></u></label>
                     <input type="password" name="password" class="form-control" />
                     <br />
                     <input type="submit" name="login" value="Login" class="btn btn-info" />
                     <br />
                     <p style="color:Red;" align="center"><a href="index.php"><b><u>Register</u></b></a></p>
                </form>
                <?php
                }
                else
                {
                ?>
                <h3 align="center">Register</h3>
                <br />
                <form method="post">
                     <label style="color:Blue;">Enter Username</label>
                     <input type="text" name="username" class="form-control" />
                     <br />
                     <label style="color:Blue;">Enter Password</label>
                     <input type="password" name="password" class="form-control" />
                     <br />
                     <input type="submit" name="register" value="Register" class="btn btn-info" />
                     <br />
                     <p style="color:Tomato;" align="center"><a href="index.php?action=login"><b><u>Login</u></b></a></p>
                </form>
                <?php
                }
                ?>
           </div>
      </body>
 </html>
