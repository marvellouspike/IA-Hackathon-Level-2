<?php include 'filesdel.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="style.css">
    <title>SEC CODING CH#4 : UNRECOVERABLE</title>
  </head>
  <body style="background-color:Khaki;">
    <div class="container">
      <div class="row">
        <form style="background-color:PowderBlue;" action="index.php" method="post" enctype="multipart/form-data" >
          <h3>Upload File to Secure Delete</h3>
          <input type="file" name="myfile"> <br>
          <button type="submit" name="upload">upload</button><br>
          <button type="submit" name="delete">Secure Delete</button><br>
        </form>
      </div>
    </div>
  </body>
</html>
