<?php
// connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'filedel');
$sql = "SELECT * FROM files";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);
// Uploads files
if (isset($_POST['upload'])) { // if upload button on the form is clicked
    // name of the uploaded file
    $fname = $_FILES['myfile']['name'];
    $destination = 'uploads/' . $fname;
    $extension = pathinfo($fname, PATHINFO_EXTENSION);
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if(move_uploaded_file($file, $destination)) {
        // move the uploaded (temporary) file to the specified destination
        $sql = "INSERT INTO files (name, size, downloads) VALUES ('$fname', $size, 0)";
        echo "File uploaded successfully";
            }
         else {
            echo "Failed to upload file.";
        }
  }
if (isset($_POST['delete'])) {
//unset($filename);
$file_ptr = fopen('uploads/$fname','w+');
fclose($file_ptr);
if(unlink('filedel/uploads/$fname')) {
  echo '<script>alert("SUCCESS : File Deleted Permanently")</script>';
}
else {
echo '<script>alert("File Deletion Failed")</script>';

}
//    try {
  //    unlink($file);
    //  echo '<script>alert("SUCCESS : File Deleted Permanently")</script>';
      //  }
    //    catch(Exception $e) {
      //      echo '<script>alert("File Deletion Failed")</script>';
    //    }
      }
    ?>
